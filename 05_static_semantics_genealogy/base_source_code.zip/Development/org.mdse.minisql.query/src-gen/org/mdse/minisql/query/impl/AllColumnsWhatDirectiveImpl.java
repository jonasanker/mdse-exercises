/**
 */
package org.mdse.minisql.query.impl;

import org.eclipse.emf.ecore.EClass;

import org.mdse.minisql.query.AllColumnsWhatDirective;
import org.mdse.minisql.query.QueryPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>All Columns What Directive</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AllColumnsWhatDirectiveImpl extends WhatDirectiveImpl implements AllColumnsWhatDirective {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AllColumnsWhatDirectiveImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return QueryPackage.Literals.ALL_COLUMNS_WHAT_DIRECTIVE;
	}

} //AllColumnsWhatDirectiveImpl
