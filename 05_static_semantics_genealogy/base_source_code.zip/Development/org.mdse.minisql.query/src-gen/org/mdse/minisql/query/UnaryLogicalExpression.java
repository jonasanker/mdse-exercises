/**
 */
package org.mdse.minisql.query;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unary Logical Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.mdse.minisql.query.QueryPackage#getUnaryLogicalExpression()
 * @model
 * @generated
 */
public interface UnaryLogicalExpression extends Unary, LogicalExpression {
} // UnaryLogicalExpression
