/**
 */
package org.mdse.minisql.query.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.mdse.minisql.query.QueryPackage;
import org.mdse.minisql.query.WhatDirective;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>What Directive</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class WhatDirectiveImpl extends MinimalEObjectImpl.Container implements WhatDirective {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WhatDirectiveImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return QueryPackage.Literals.WHAT_DIRECTIVE;
	}

} //WhatDirectiveImpl
