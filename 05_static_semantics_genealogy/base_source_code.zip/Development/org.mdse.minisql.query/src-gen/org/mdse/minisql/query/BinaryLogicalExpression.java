/**
 */
package org.mdse.minisql.query;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Binary Logical Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.mdse.minisql.query.QueryPackage#getBinaryLogicalExpression()
 * @model
 * @generated
 */
public interface BinaryLogicalExpression extends Binary, LogicalExpression {
} // BinaryLogicalExpression
