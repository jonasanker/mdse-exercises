/**
 */
package org.mdse.minisql.query;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Literal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.mdse.minisql.query.QueryPackage#getLiteral()
 * @model abstract="true"
 * @generated
 */
public interface Literal extends Expression {
} // Literal
