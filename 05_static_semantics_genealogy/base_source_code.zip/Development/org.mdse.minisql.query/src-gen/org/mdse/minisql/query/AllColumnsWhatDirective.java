/**
 */
package org.mdse.minisql.query;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>All Columns What Directive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.mdse.minisql.query.QueryPackage#getAllColumnsWhatDirective()
 * @model
 * @generated
 */
public interface AllColumnsWhatDirective extends WhatDirective {
} // AllColumnsWhatDirective
