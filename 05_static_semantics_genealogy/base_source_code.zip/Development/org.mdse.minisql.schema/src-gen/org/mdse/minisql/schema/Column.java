/**
 */
package org.mdse.minisql.schema;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Column</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.mdse.minisql.schema.SchemaPackage#getColumn()
 * @model
 * @generated
 */
public interface Column extends NamedElement {
} // Column
